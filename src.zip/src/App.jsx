import './App.css'
import MyMap from './MyMap';

function App() {
  return (
    <>
      <MyMap></MyMap>
    </>
  );
};

export default App;
